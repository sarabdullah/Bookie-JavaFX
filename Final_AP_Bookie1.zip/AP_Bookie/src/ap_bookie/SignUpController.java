/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ap_bookie;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
//import org.hibernate.Session;
//import org.hibernate.Transaction;

/**
 * FXML Controller class
 *
 * @author hp
 */
public class SignUpController implements Initializable {

    private Stage stage;
    private Scene scene;
    private Parent root;
    @FXML
    private ComboBox Interests0;

    /**
     * Initializes the controller class.
     */
    @FXML
    Label lblmsg;

    ObservableList<String> usernme = FXCollections.observableArrayList();
    ObservableList<String> email = FXCollections.observableArrayList();
    ObservableList<String> password = FXCollections.observableArrayList();
    ObservableList<String> birthDte = FXCollections.observableArrayList();

    @FXML
    private TextField signname;
    @FXML
    private TextField signemail;
    @FXML
    private PasswordField password1;
    @FXML
    private PasswordField password2;

    @FXML
    private Button signupact;
    @FXML
    private Button back;
    /*  @FXML
    private Button account; */

    @FXML
    private DatePicker birthdate;

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        Interests0.getItems().addAll("Art", "buisness", "design", "crime", "tech", "romance");
        Interests0.setValue("Art");

    }

    @FXML
    private void backbtn(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("bookie.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    public void signup(ActionEvent event) throws IOException {

        if (signemail.getText().isEmpty()
                || signname.getText().isEmpty() || password1.getText().isEmpty()) {
            lblmsg.setText("**Please enter your information");
            lblmsg.setTextFill(Color.color(1, 0, 0));

        } else if (password1.getText().length() <= 8) {
            lblmsg.setText("The length of password must be 8 digits at least");
            lblmsg.setTextFill(Color.color(1, 0, 0));
        } else if (password1.getText() == null ? password2.getText() != null : !password1.getText().equals(password2.getText())) {
            lblmsg.setText("password don't match");

            f(usernme.contains(signname.getText()) || email.contains(signemail.getText()))
            {
                lblmsg.setText("This user is already exists");
                lblmsg.setTextFill(Color.color(1, 0, 0));
            }
        } else if (usernme.contains(signname.getText()) || email.contains(signemail.getText())) {
            lblmsg.setText("This user is already exists");
            lblmsg.setTextFill(Color.color(1, 0, 0));
        } else {
            userinfo u = new userinfo();
            u.setEmailDB(signemail.getText());
            u.setPasswordDB(password1.getText());
            u.setUsernmeDB(signname.getText());

            Session session1 = HibernateUtil.getSessionFactory().openSession();
            session1 = HibernateUtil.getSessionFactory().openSession();
            Transaction tx = session1.beginTransaction();
            session1.save(u);
            tx.commit();
            session1.close();

            root = FXMLLoader.load(getClass().getResource("LogIn.fxml"));
            stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }

    }

}

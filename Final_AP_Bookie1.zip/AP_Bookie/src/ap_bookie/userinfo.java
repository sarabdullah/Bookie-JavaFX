/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ap_bookie;

//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.Id;
//import javax.persistence.Table;
//
///**
// *
// * @author almso
// */
//
//@Entity
//@Table(name="USERINFO")
//
//
public class userinfo implements java.io.Serializable {
//    
//    
//    
//    @Id
//    @Column(name = "usernme")
    private String usernmeDB;
//    @Column(name = "email")
    private String emailDB;
//    @Column(name = "password")
    private String passwordDB;
//    @Column(name = "birthDte")
    private String birthDteDB;

    
    public userinfo() {
        
        
    }

    public String getUsernmeDB() {
        return usernmeDB;
    }

    public String getEmailDB() {
        return emailDB;
    }

    public String getPasswordDB() {
        return passwordDB;
    }

    public String getBirthDteDB() {
        return birthDteDB;
    }

    public void setUsernmeDB(String usernmeDB) {
        this.usernmeDB = usernmeDB;
    }

    public void setEmailDB(String emailDB) {
        this.emailDB = emailDB;
    }

    public void setPasswordDB(String passwordDB) {
        this.passwordDB = passwordDB;
    }

    public void setBirthDteDB(String birthDteDB) {
        this.birthDteDB = birthDteDB;
    }
    
    
    
    
    
}

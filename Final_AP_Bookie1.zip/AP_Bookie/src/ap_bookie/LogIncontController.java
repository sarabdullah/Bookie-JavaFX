/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ap_bookie;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author almso
 */
public class LogIncontController implements Initializable {
    
    
    private Stage stage;
    private Scene scene;
    private Parent root;
    @FXML
    private TextField nlogin;
    @FXML
    private PasswordField plogin;
    
    ObservableList<String> usernme= FXCollections.observableArrayList();
    ObservableList<String> email= FXCollections.observableArrayList();
    ObservableList<String> password= FXCollections.observableArrayList();
    ObservableList<String> birthDte= FXCollections.observableArrayList();
    
    
    @FXML
    Label lblmsg;
    @FXML
    private Button logbtn2;
    @FXML
    private Button back;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }   
    @FXML
    private void backbtn(ActionEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("bookie.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    
    
    
    @FXML
    private void login(MouseEvent event) throws IOException {
        if(nlogin.getText().isEmpty()||plogin.getText().isEmpty()){
            lblmsg.setText("**Please enter your userName and password");
            lblmsg.setTextFill(Color.color(1, 0, 0));
        }
        
//        else if(usernme.contains(nlogin.getText())&&password.contains(plogin.getText())
//        &&!nlogin.getText().isEmpty()&&!plogin.getText().isEmpty())
//        {
//            lblmsg.setText("welcome! " + nlogin.getText());
//            lblmsg.setTextFill(Color.GREEN);
//         
//            //then  go to home page                                          
//            root = FXMLLoader.load(getClass().getResource("Explore.fxml"));
//            stage = (Stage)((Node)event.getSource()).getScene().getWindow();
//            scene = new Scene(root);
//            stage.setScene(scene);
//            stage.show();
//        }
        
        else
        {
//            lblmsg.setText("Incorrect user or password.");
//            lblmsg.setTextFill(Color.RED);
            //then  go to home page                                          
            root = FXMLLoader.load(getClass().getResource("Explore.fxml"));
            stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }
    }

 


    

   


}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ap_bookie;

import com.sun.tools.javac.Main;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollBar;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author hp
 */
public class ExploreController implements Initializable {

    private Stage stage;
    private Scene scene;
    private Parent root;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void tprofile(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("profile1.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void tfavorite(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Favorite.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void tlibary(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Libary.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
///////////////////////////////////////////////////////////

    @FXML
    private void exploremine(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Explore.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void tart(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Art.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void tHistory(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("History.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void tDesign(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Design.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    private void tBusiness(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Business.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void tRomance(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Romance.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void tCrime_Thriller(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Crime.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void tChildren(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Children.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void tTechnology(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Technology.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void tbook1(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Book1.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void book2(MouseEvent event) throws IOException { ///"ap_bookie.picss/book2.fxml"

        root = FXMLLoader.load(getClass().getResource("Book2.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    private void book3(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Book3.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
@FXML
    private void book4(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Book4.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
@FXML
    private void book5(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Book5.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
@FXML
    private void book6(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Book6.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    private void book7(MouseEvent event) throws IOException {

        root = FXMLLoader.load(getClass().getResource("Book7.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
@FXML
    private void book8(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Book8.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
@FXML
    private void book9(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Book9.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
@FXML
    private void book10(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Book10.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
@FXML
    private void book11(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Book11.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
@FXML
    private void book12(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Book12.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
@FXML
    private void book13(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Book13.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
@FXML
    private void book14(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Book14.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
@FXML
    private void book15(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Book15.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
@FXML
    private void book16(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Book16.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
@FXML
    private void book17(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Book17.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
@FXML
    private void book18(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Book18.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
@FXML
    private void book19(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Book19.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
@FXML
    private void book20(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Book20.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
@FXML
    private void book21(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Book21.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
@FXML
    private void book22(MouseEvent event) throws IOException {
        root = FXMLLoader.load(getClass().getResource("Book22.fxml"));
        stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

}
